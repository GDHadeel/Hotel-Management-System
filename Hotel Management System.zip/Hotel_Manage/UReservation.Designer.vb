﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UReservation
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.dtresdate = New System.Windows.Forms.DateTimePicker()
        Me.txtresemail = New System.Windows.Forms.TextBox()
        Me.txtreslname = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CCBresgender = New System.Windows.Forms.ComboBox()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.Btnupdate = New System.Windows.Forms.Button()
        Me.Btninsert = New System.Windows.Forms.Button()
        Me.txtresname = New System.Windows.Forms.TextBox()
        Me.txtresid = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Location = New System.Drawing.Point(583, 174)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(557, 462)
        Me.Panel2.TabIndex = 114
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 33
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(551, 456)
        Me.DataGridView1.TabIndex = 19
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Red
        Me.Button4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(1037, 21)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(52, 47)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "X"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'dtresdate
        '
        Me.dtresdate.CalendarFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dtresdate.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dtresdate.Location = New System.Drawing.Point(195, 461)
        Me.dtresdate.Name = "dtresdate"
        Me.dtresdate.Size = New System.Drawing.Size(358, 39)
        Me.dtresdate.TabIndex = 113
        '
        'txtresemail
        '
        Me.txtresemail.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtresemail.Location = New System.Drawing.Point(195, 397)
        Me.txtresemail.Name = "txtresemail"
        Me.txtresemail.Size = New System.Drawing.Size(356, 39)
        Me.txtresemail.TabIndex = 112
        '
        'txtreslname
        '
        Me.txtreslname.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtreslname.Location = New System.Drawing.Point(195, 256)
        Me.txtreslname.Name = "txtreslname"
        Me.txtreslname.Size = New System.Drawing.Size(356, 39)
        Me.txtreslname.TabIndex = 111
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(60, 469)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(129, 28)
        Me.Label5.TabIndex = 110
        Me.Label5.Text = "RES Date:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(49, 403)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(140, 28)
        Me.Label6.TabIndex = 109
        Me.Label6.Text = "RES Email:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(27, 332)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(162, 28)
        Me.Label7.TabIndex = 108
        Me.Label7.Text = "RES Gender:"
        '
        'CCBresgender
        '
        Me.CCBresgender.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CCBresgender.FormattingEnabled = True
        Me.CCBresgender.Location = New System.Drawing.Point(195, 326)
        Me.CCBresgender.Name = "CCBresgender"
        Me.CCBresgender.Size = New System.Drawing.Size(356, 40)
        Me.CCBresgender.TabIndex = 107
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Red
        Me.btndelete.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btndelete.ForeColor = System.Drawing.Color.White
        Me.btndelete.Location = New System.Drawing.Point(394, 580)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(157, 56)
        Me.btndelete.TabIndex = 106
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'Btnupdate
        '
        Me.Btnupdate.BackColor = System.Drawing.Color.Orange
        Me.Btnupdate.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnupdate.ForeColor = System.Drawing.Color.White
        Me.Btnupdate.Location = New System.Drawing.Point(213, 580)
        Me.Btnupdate.Name = "Btnupdate"
        Me.Btnupdate.Size = New System.Drawing.Size(157, 56)
        Me.Btnupdate.TabIndex = 105
        Me.Btnupdate.Text = "UPDATE"
        Me.Btnupdate.UseVisualStyleBackColor = False
        '
        'Btninsert
        '
        Me.Btninsert.BackColor = System.Drawing.Color.Green
        Me.Btninsert.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btninsert.ForeColor = System.Drawing.Color.White
        Me.Btninsert.Location = New System.Drawing.Point(32, 580)
        Me.Btninsert.Name = "Btninsert"
        Me.Btninsert.Size = New System.Drawing.Size(157, 56)
        Me.Btninsert.TabIndex = 104
        Me.Btninsert.Text = "INSERT"
        Me.Btninsert.UseVisualStyleBackColor = False
        '
        'txtresname
        '
        Me.txtresname.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtresname.Location = New System.Drawing.Point(195, 188)
        Me.txtresname.Name = "txtresname"
        Me.txtresname.Size = New System.Drawing.Size(356, 39)
        Me.txtresname.TabIndex = 103
        '
        'txtresid
        '
        Me.txtresid.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtresid.Location = New System.Drawing.Point(195, 121)
        Me.txtresid.Name = "txtresid"
        Me.txtresid.Size = New System.Drawing.Size(356, 39)
        Me.txtresid.TabIndex = 102
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(37, 262)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(152, 28)
        Me.Label4.TabIndex = 101
        Me.Label4.Text = "RES Lname:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(47, 194)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(142, 28)
        Me.Label3.TabIndex = 100
        Me.Label3.Text = "RES Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(91, 127)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 28)
        Me.Label2.TabIndex = 99
        Me.Label2.Text = "RES Id:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Britannic Bold", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(213, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(340, 58)
        Me.Label1.TabIndex = 98
        Me.Label1.Text = "RESERVATION"
        '
        'UReservation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.dtresdate)
        Me.Controls.Add(Me.txtresemail)
        Me.Controls.Add(Me.txtreslname)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CCBresgender)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.Btnupdate)
        Me.Controls.Add(Me.Btninsert)
        Me.Controls.Add(Me.txtresname)
        Me.Controls.Add(Me.txtresid)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UReservation"
        Me.Size = New System.Drawing.Size(1166, 670)
        Me.Panel2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button4 As Button
    Friend WithEvents dtresdate As DateTimePicker
    Friend WithEvents txtresemail As TextBox
    Friend WithEvents txtreslname As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CCBresgender As ComboBox
    Friend WithEvents btndelete As Button
    Friend WithEvents Btnupdate As Button
    Friend WithEvents Btninsert As Button
    Friend WithEvents txtresname As TextBox
    Friend WithEvents txtresid As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
