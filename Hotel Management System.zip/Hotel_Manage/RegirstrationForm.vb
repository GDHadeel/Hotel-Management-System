﻿Imports System.Data.SqlClient
Imports System.Data.Sql
Public Class RegirstrationForm
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Dim login As New LoginForm
        login.Show()
        Me.Hide()
    End Sub

    Private Sub lbllogin_Click(sender As Object, e As EventArgs) Handles lbllogin.Click
        Dim login1 As New LoginForm1
        login1.Show()
        Me.Hide()
    End Sub

    Sub clear()
        txtuserid.Text = ""
        txtfullname.Text = ""
        txtpassword.Text = ""
        txtusername.Text = ""
        ccbgender.Text = ""
        txtuserid.Focus()

    End Sub

    Private Sub lblregisterbutton_Click(sender As Object, e As EventArgs) Handles lblregisterbutton.Click
        If txtuserid.Text = "" Or txtfullname.Text = "" Or txtusername.Text = "" Or txtpassword.Text = "" Or ccbgender.Text = "" Then
            MessageBox.Show("register fail")
        Else
            MessageBox.Show("register complete")
            Dim con As New SqlConnection
            Dim cmd As New SqlCommand
            con = getconnection()
            con.Open()
            cmd = con.CreateCommand
            cmd.CommandText = "INSERT INTO registeruser(userid, fullname, username, password, gender) VALUES (@id, @full, @user, @pass, @gender)"
            Dim da As New SqlDataAdapter(cmd.CommandText, con)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("id", txtuserid.Text)
            cmd.Parameters.AddWithValue("full", txtfullname.Text)
            cmd.Parameters.AddWithValue("user", txtusername.Text)
            cmd.Parameters.AddWithValue("pass", txtpassword.Text)
            cmd.Parameters.AddWithValue("gender", ccbgender.Text)
            cmd.ExecuteNonQuery()
            clear()
            con.Close()
        End If

    End Sub

    Private Sub RegirstrationForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ccbgender.Text = "none"
        ccbgender.Items.Add("Male")
        ccbgender.Items.Add("Female")

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged

    End Sub
End Class

