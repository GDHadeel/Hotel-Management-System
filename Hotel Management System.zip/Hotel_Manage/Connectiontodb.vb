﻿Imports System.Data.SqlClient
Imports System.Data.Sql
Module Connectiontodb
    Dim con As New SqlConnection
    Public Function getconnection() As SqlConnection
        con = New SqlConnection("Data Source=LAPTOP-IJH7VKDL;Initial Catalog=Hotel_Manage;Integrated Security=True")
        Return con
    End Function
End Module