﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Mainform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btnclient = New System.Windows.Forms.Button()
        Me.Btnroom = New System.Windows.Forms.Button()
        Me.BtnReservation = New System.Windows.Forms.Button()
        Me.Btnexit1 = New System.Windows.Forms.Button()
        Me.lblcusor = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.UClients1 = New Hotel_Manage.UClients()
        Me.UReservation1 = New Hotel_Manage.UReservation()
        Me.URooms1 = New Hotel_Manage.URooms()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 223)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1185, 720)
        Me.Panel2.TabIndex = 38
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Britannic Bold", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(324, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(570, 58)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "MANAGE HOTEL SYSTEM"
        '
        'Btnclient
        '
        Me.Btnclient.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Btnclient.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnclient.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btnclient.Location = New System.Drawing.Point(12, 159)
        Me.Btnclient.Name = "Btnclient"
        Me.Btnclient.Size = New System.Drawing.Size(174, 54)
        Me.Btnclient.TabIndex = 34
        Me.Btnclient.Text = "Clients"
        Me.Btnclient.UseVisualStyleBackColor = False
        '
        'Btnroom
        '
        Me.Btnroom.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Btnroom.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnroom.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btnroom.Location = New System.Drawing.Point(210, 159)
        Me.Btnroom.Name = "Btnroom"
        Me.Btnroom.Size = New System.Drawing.Size(174, 54)
        Me.Btnroom.TabIndex = 35
        Me.Btnroom.Text = "Rooms"
        Me.Btnroom.UseVisualStyleBackColor = False
        '
        'BtnReservation
        '
        Me.BtnReservation.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BtnReservation.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnReservation.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnReservation.Location = New System.Drawing.Point(408, 159)
        Me.BtnReservation.Name = "BtnReservation"
        Me.BtnReservation.Size = New System.Drawing.Size(174, 54)
        Me.BtnReservation.TabIndex = 36
        Me.BtnReservation.Text = "Reservation"
        Me.BtnReservation.UseVisualStyleBackColor = False
        '
        'Btnexit1
        '
        Me.Btnexit1.BackColor = System.Drawing.Color.Red
        Me.Btnexit1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnexit1.ForeColor = System.Drawing.Color.White
        Me.Btnexit1.Location = New System.Drawing.Point(1121, 12)
        Me.Btnexit1.Name = "Btnexit1"
        Me.Btnexit1.Size = New System.Drawing.Size(52, 47)
        Me.Btnexit1.TabIndex = 37
        Me.Btnexit1.Text = "X"
        Me.Btnexit1.UseVisualStyleBackColor = False
        '
        'lblcusor
        '
        Me.lblcusor.AutoSize = True
        Me.lblcusor.BackColor = System.Drawing.Color.Red
        Me.lblcusor.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblcusor.Location = New System.Drawing.Point(16, 208)
        Me.lblcusor.MaximumSize = New System.Drawing.Size(5, 5)
        Me.lblcusor.MinimumSize = New System.Drawing.Size(168, 5)
        Me.lblcusor.Name = "lblcusor"
        Me.lblcusor.Size = New System.Drawing.Size(168, 5)
        Me.lblcusor.TabIndex = 16
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(18, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(168, 130)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.lblcusor)
        Me.Panel1.Controls.Add(Me.Btnexit1)
        Me.Panel1.Controls.Add(Me.BtnReservation)
        Me.Panel1.Controls.Add(Me.Btnroom)
        Me.Panel1.Controls.Add(Me.Btnclient)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1185, 223)
        Me.Panel1.TabIndex = 0
        '
        'UClients1
        '
        Me.UClients1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.UClients1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UClients1.Location = New System.Drawing.Point(0, 223)
        Me.UClients1.Name = "UClients1"
        Me.UClients1.Size = New System.Drawing.Size(1185, 720)
        Me.UClients1.TabIndex = 39
        '
        'UReservation1
        '
        Me.UReservation1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.UReservation1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UReservation1.Location = New System.Drawing.Point(0, 223)
        Me.UReservation1.Name = "UReservation1"
        Me.UReservation1.Size = New System.Drawing.Size(1185, 720)
        Me.UReservation1.TabIndex = 40
        '
        'URooms1
        '
        Me.URooms1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.URooms1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.URooms1.Location = New System.Drawing.Point(0, 223)
        Me.URooms1.Name = "URooms1"
        Me.URooms1.Size = New System.Drawing.Size(1185, 720)
        Me.URooms1.TabIndex = 41
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(1063, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(52, 47)
        Me.Button1.TabIndex = 38
        Me.Button1.Text = "_"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Mainform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1185, 943)
        Me.Controls.Add(Me.URooms1)
        Me.Controls.Add(Me.UReservation1)
        Me.Controls.Add(Me.UClients1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Mainform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "mainform1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Btnclient As Button
    Friend WithEvents Btnroom As Button
    Friend WithEvents BtnReservation As Button
    Friend WithEvents Btnexit1 As Button
    Friend WithEvents lblcusor As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents UClients1 As UClients
    Friend WithEvents UReservation1 As UReservation
    Friend WithEvents URooms1 As URooms
    Friend WithEvents Button1 As Button
End Class
