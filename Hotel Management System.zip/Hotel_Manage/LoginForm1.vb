﻿Imports System.Data.SqlClient
Imports System.Data.Sql
Public Class LoginForm1
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Dim login As New LoginForm
        login.Show()
        Me.Hide()
    End Sub

    Private Sub lblsignup_Click(sender As Object, e As EventArgs) Handles lblsignup.Click
        Dim register As New RegirstrationForm
        register.Show()
        Me.Hide()
    End Sub

    Private Sub lblloginbutton_Click(sender As Object, e As EventArgs) Handles lblloginbutton.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM registeruser WHERE username ='" & txtusername.Text & "' AND password = '" & txtpassword.Text & "'"
        Dim da As New SqlDataAdapter(cmd.CommandText, con)
        Dim dt As New DataTable
        da.Fill(dt)
        Dim dr As SqlDataReader = cmd.ExecuteReader
        If dr.Read = False Then
            MessageBox.Show("username and password incorrect")
        Else
            Dim i As Integer = dt.Rows.Count - 1
            mainform.Show()
            Me.Hide()
            txtusername.Text = ""
            txtpassword.Text = ""
            txtusername.Focus()
        End If
        con.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            txtpassword.UseSystemPasswordChar = False
        Else
            txtpassword.UseSystemPasswordChar = True
        End If
    End Sub
End Class