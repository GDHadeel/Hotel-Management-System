﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UClients
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtclientdate = New System.Windows.Forms.DateTimePicker()
        Me.txtclientemail = New System.Windows.Forms.TextBox()
        Me.txtclientlname = New System.Windows.Forms.TextBox()
        Me.lblclientdate = New System.Windows.Forms.Label()
        Me.lblclientemail = New System.Windows.Forms.Label()
        Me.lblclientgender = New System.Windows.Forms.Label()
        Me.CCbclientgender = New System.Windows.Forms.ComboBox()
        Me.txtclientname = New System.Windows.Forms.TextBox()
        Me.txtclientid = New System.Windows.Forms.TextBox()
        Me.lblclientlname = New System.Windows.Forms.Label()
        Me.lblclientname = New System.Windows.Forms.Label()
        Me.lblclientid = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.Btninsert = New System.Windows.Forms.Button()
        Me.lbllclients = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dtclientdate
        '
        Me.dtclientdate.CalendarFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dtclientdate.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dtclientdate.Location = New System.Drawing.Point(202, 467)
        Me.dtclientdate.Name = "dtclientdate"
        Me.dtclientdate.Size = New System.Drawing.Size(358, 39)
        Me.dtclientdate.TabIndex = 125
        '
        'txtclientemail
        '
        Me.txtclientemail.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtclientemail.Location = New System.Drawing.Point(202, 403)
        Me.txtclientemail.Name = "txtclientemail"
        Me.txtclientemail.Size = New System.Drawing.Size(356, 39)
        Me.txtclientemail.TabIndex = 124
        '
        'txtclientlname
        '
        Me.txtclientlname.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtclientlname.Location = New System.Drawing.Point(202, 262)
        Me.txtclientlname.Name = "txtclientlname"
        Me.txtclientlname.Size = New System.Drawing.Size(356, 39)
        Me.txtclientlname.TabIndex = 123
        '
        'lblclientdate
        '
        Me.lblclientdate.AutoSize = True
        Me.lblclientdate.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientdate.Location = New System.Drawing.Point(48, 475)
        Me.lblclientdate.Name = "lblclientdate"
        Me.lblclientdate.Size = New System.Drawing.Size(148, 28)
        Me.lblclientdate.TabIndex = 122
        Me.lblclientdate.Text = "Client Date:"
        '
        'lblclientemail
        '
        Me.lblclientemail.AutoSize = True
        Me.lblclientemail.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientemail.Location = New System.Drawing.Point(37, 409)
        Me.lblclientemail.Name = "lblclientemail"
        Me.lblclientemail.Size = New System.Drawing.Size(159, 28)
        Me.lblclientemail.TabIndex = 121
        Me.lblclientemail.Text = "Client Email:"
        '
        'lblclientgender
        '
        Me.lblclientgender.AutoSize = True
        Me.lblclientgender.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientgender.Location = New System.Drawing.Point(15, 338)
        Me.lblclientgender.Name = "lblclientgender"
        Me.lblclientgender.Size = New System.Drawing.Size(181, 28)
        Me.lblclientgender.TabIndex = 120
        Me.lblclientgender.Text = "Client Gender:"
        '
        'CCbclientgender
        '
        Me.CCbclientgender.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CCbclientgender.FormattingEnabled = True
        Me.CCbclientgender.Location = New System.Drawing.Point(202, 332)
        Me.CCbclientgender.Name = "CCbclientgender"
        Me.CCbclientgender.Size = New System.Drawing.Size(356, 40)
        Me.CCbclientgender.TabIndex = 119
        '
        'txtclientname
        '
        Me.txtclientname.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtclientname.Location = New System.Drawing.Point(202, 194)
        Me.txtclientname.Name = "txtclientname"
        Me.txtclientname.Size = New System.Drawing.Size(356, 39)
        Me.txtclientname.TabIndex = 118
        '
        'txtclientid
        '
        Me.txtclientid.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtclientid.Location = New System.Drawing.Point(202, 127)
        Me.txtclientid.Name = "txtclientid"
        Me.txtclientid.Size = New System.Drawing.Size(356, 39)
        Me.txtclientid.TabIndex = 117
        '
        'lblclientlname
        '
        Me.lblclientlname.AutoSize = True
        Me.lblclientlname.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientlname.Location = New System.Drawing.Point(25, 268)
        Me.lblclientlname.Name = "lblclientlname"
        Me.lblclientlname.Size = New System.Drawing.Size(171, 28)
        Me.lblclientlname.TabIndex = 116
        Me.lblclientlname.Text = "Client Lname:"
        '
        'lblclientname
        '
        Me.lblclientname.AutoSize = True
        Me.lblclientname.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientname.Location = New System.Drawing.Point(35, 200)
        Me.lblclientname.Name = "lblclientname"
        Me.lblclientname.Size = New System.Drawing.Size(161, 28)
        Me.lblclientname.TabIndex = 115
        Me.lblclientname.Text = "Client Name:"
        '
        'lblclientid
        '
        Me.lblclientid.AutoSize = True
        Me.lblclientid.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblclientid.Location = New System.Drawing.Point(79, 133)
        Me.lblclientid.Name = "lblclientid"
        Me.lblclientid.Size = New System.Drawing.Size(117, 28)
        Me.lblclientid.TabIndex = 114
        Me.lblclientid.Text = "Client Id:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Location = New System.Drawing.Point(594, 174)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(557, 462)
        Me.Panel1.TabIndex = 113
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 33
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(551, 456)
        Me.DataGridView1.TabIndex = 19
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Red
        Me.btndelete.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btndelete.ForeColor = System.Drawing.Color.White
        Me.btndelete.Location = New System.Drawing.Point(401, 580)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(157, 56)
        Me.btndelete.TabIndex = 112
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnupdate
        '
        Me.btnupdate.BackColor = System.Drawing.Color.Orange
        Me.btnupdate.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnupdate.ForeColor = System.Drawing.Color.White
        Me.btnupdate.Location = New System.Drawing.Point(220, 580)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(157, 56)
        Me.btnupdate.TabIndex = 111
        Me.btnupdate.Text = "UPDATE"
        Me.btnupdate.UseVisualStyleBackColor = False
        '
        'Btninsert
        '
        Me.Btninsert.BackColor = System.Drawing.Color.Green
        Me.Btninsert.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btninsert.ForeColor = System.Drawing.Color.White
        Me.Btninsert.Location = New System.Drawing.Point(39, 580)
        Me.Btninsert.Name = "Btninsert"
        Me.Btninsert.Size = New System.Drawing.Size(157, 56)
        Me.Btninsert.TabIndex = 110
        Me.Btninsert.Text = "INSERT"
        Me.Btninsert.UseVisualStyleBackColor = False
        '
        'lbllclients
        '
        Me.lbllclients.AutoSize = True
        Me.lbllclients.Font = New System.Drawing.Font("Britannic Bold", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbllclients.ForeColor = System.Drawing.Color.White
        Me.lbllclients.Location = New System.Drawing.Point(220, 35)
        Me.lbllclients.Name = "lbllclients"
        Me.lbllclients.Size = New System.Drawing.Size(213, 58)
        Me.lbllclients.TabIndex = 109
        Me.lbllclients.Text = "CLIENTS"
        '
        'UClients
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.dtclientdate)
        Me.Controls.Add(Me.txtclientemail)
        Me.Controls.Add(Me.txtclientlname)
        Me.Controls.Add(Me.lblclientdate)
        Me.Controls.Add(Me.lblclientemail)
        Me.Controls.Add(Me.lblclientgender)
        Me.Controls.Add(Me.CCbclientgender)
        Me.Controls.Add(Me.txtclientname)
        Me.Controls.Add(Me.txtclientid)
        Me.Controls.Add(Me.lblclientlname)
        Me.Controls.Add(Me.lblclientname)
        Me.Controls.Add(Me.lblclientid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.Btninsert)
        Me.Controls.Add(Me.lbllclients)
        Me.Name = "UClients"
        Me.Size = New System.Drawing.Size(1166, 670)
        Me.Panel1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtclientdate As DateTimePicker
    Friend WithEvents txtclientemail As TextBox
    Friend WithEvents txtclientlname As TextBox
    Friend WithEvents lblclientdate As Label
    Friend WithEvents lblclientemail As Label
    Friend WithEvents lblclientgender As Label
    Friend WithEvents CCbclientgender As ComboBox
    Friend WithEvents txtclientname As TextBox
    Friend WithEvents txtclientid As TextBox
    Friend WithEvents lblclientlname As Label
    Friend WithEvents lblclientname As Label
    Friend WithEvents lblclientid As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btndelete As Button
    Friend WithEvents btnupdate As Button
    Friend WithEvents Btninsert As Button
    Friend WithEvents lbllclients As Label
End Class
