﻿Imports System.Data.SqlClient
Imports System.Data
Public Class UClients

    Private Sub UClients_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        showata()
        CCbclientgender.Text = "none"
        CCbclientgender.Items.Add("Male")
        CCbclientgender.Items.Add("Female")
    End Sub

    Sub showata()
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM Clients"
        Dim da As New SqlDataAdapter(cmd.CommandText, con)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        con.Close()
    End Sub

    Sub clear()
        txtclientid.Text = ""
        txtclientname.Text = ""
        txtclientlname.Text = ""
        txtclientemail.Text = ""
        CCbclientgender.Text = ""
        dtclientdate.Text = ""
    End Sub

    Private Sub Btninsert_Click(sender As Object, e As EventArgs) Handles Btninsert.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM Clients WHERE clientid=@id"
        cmd.Parameters.AddWithValue("id", txtclientid.Text)
        Dim dr As SqlDataReader = cmd.ExecuteReader
        If dr.HasRows Then
            MessageBox.Show("The" & txtclientid.Text & "Clientid Is already existed")
            clear()
        Else
            If txtclientid.Text = "" Or txtclientname.Text = "" Or txtclientlname.Text = "" Or CCbclientgender.Text = "" Or txtclientemail.Text = "" Or dtclientdate.Text = "" Then
                MessageBox.Show("Please insert your info")
            Else
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "INSERT INTO Clients(clientid, clientname, clientlname, clientgender, clientemail, clientdate)  VALUES(@id, @name, @lname, @gender, @email, @date)"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtclientid.Text)
                cmd.Parameters.AddWithValue("name", txtclientname.Text)
                cmd.Parameters.AddWithValue("lname", txtclientlname.Text)
                cmd.Parameters.AddWithValue("gender", CCbclientgender.Text)
                cmd.Parameters.AddWithValue("email", txtclientemail.Text)
                cmd.Parameters.AddWithValue("date", dtclientdate.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If

    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        If txtclientid.Text = "" Or txtclientname.Text = "" Or txtclientlname.Text = "" Or CCbclientgender.Text = "" Or txtclientemail.Text = "" Or dtclientdate.Text = "" Then
            MessageBox.Show("Please selsct your info")
        Else
            Dim con As New SqlConnection
            Dim cmd As New SqlCommand
            con = getconnection()
            con.Open()
            cmd = con.CreateCommand
            cmd.CommandText = "UPDATE Clients SET clientname=@name, clientlname=@name, clientgender=@gender, clientemail=@email, clientdate=@date WHERE clientid=@id"
            Dim da As New SqlDataAdapter(cmd.CommandText, con)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("id", txtclientid.Text)
            cmd.Parameters.AddWithValue("name", txtclientname.Text)
            cmd.Parameters.AddWithValue("lname", txtclientlname.Text)
            cmd.Parameters.AddWithValue("gender", CCbclientgender.Text)
            cmd.Parameters.AddWithValue("email", txtclientemail.Text)
            cmd.Parameters.AddWithValue("date", dtclientdate.Text)
            cmd.ExecuteNonQuery()
            showata()
            clear()
            con.Close()

        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim show As Integer
        show = DataGridView1.CurrentRow.Index
        txtclientid.Text = DataGridView1.Item(0, show).Value
        txtclientname.Text = DataGridView1.Item(1, show).Value
        txtclientlname.Text = DataGridView1.Item(2, show).Value
        CCbclientgender.Text = DataGridView1.Item(3, show).Value
        txtclientemail.Text = DataGridView1.Item(4, show).Value
        dtclientdate.Text = DataGridView1.Item(5, show).Value
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        If txtclientid.Text = "" Or txtclientname.Text = "" Or txtclientlname.Text = "" Or CCbclientgender.Text = "" Or txtclientemail.Text = "" Or dtclientdate.Text = "" Then
            MessageBox.Show("Please select your info you want to delete", "notice", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If MessageBox.Show("Are you sure want to delete this info", "notice", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "DELETE FROM Clients WHERE clientid=@id"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtclientid.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If
    End Sub
End Class
