﻿Imports System.Data.SqlClient
Imports System.Data
Public Class URooms
    Private Sub URooms_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        showata()

        CCbroomstype.Text = "none"
        CCbroomstype.Items.Add("SINGLE ROOM")
        CCbroomstype.Items.Add("DOUBLE ROOM")
        CCbroomstype.Items.Add("TRIPLE ROOM")
        CCbroomstype.Items.Add("FAMILY ROOM")
        CCbroomstype.Items.Add("DELUX ROOM")
    End Sub

    Sub showata()
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd.CommandText = "(SELECT * FROM Rooms)"
        Dim da As New SqlDataAdapter(cmd.CommandText, con)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        con.Close()
    End Sub

    Sub clear()
        txtroomsid.Text = ""
        txtroomsno.Text = ""
        CCbroomstype.Text = "none"
    End Sub

    Private Sub Btninsert_Click(sender As Object, e As EventArgs) Handles Btninsert.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM Rooms WHERE roomid=@id"
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("id", txtroomsid.Text)
        Dim dr As SqlDataReader = cmd.ExecuteReader
        If dr.HasRows Then
            MessageBox.Show("The" & txtroomsid.Text & "ID Room is already existed")
        Else
            If txtroomsid.Text = "" Or txtroomsno.Text = "" Or CCbroomstype.Text = "none" Then
                MessageBox.Show("Please insert your info", "notice", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "INSERT INTO Rooms(roomid, roomno, roomtype)VALUES(@id, @no, @type)"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtroomsid.Text)
                cmd.Parameters.AddWithValue("no", txtroomsno.Text)
                cmd.Parameters.AddWithValue("type", CCbroomstype.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If
    End Sub

    Private Sub Btnupdate_Click(sender As Object, e As EventArgs) Handles Btnupdate.Click
        If txtroomsid.Text = "" Or txtroomsno.Text = "" Or CCbroomstype.Text = "none" Then
            MessageBox.Show("Please insert your info", "notice", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim con As New SqlConnection
            Dim cmd As New SqlCommand
            con = getconnection()
            con.Open()
            cmd = con.CreateCommand
            cmd.CommandText = "UPDATE Rooms SET roomno=@no, roomtype=@type WHERE roomid=@id"
            Dim da As New SqlDataAdapter(cmd.CommandText, con)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("id", txtroomsid.Text)
            cmd.Parameters.AddWithValue("no", txtroomsno.Text)
            cmd.Parameters.AddWithValue("type", CCbroomstype.Text)
            cmd.ExecuteNonQuery()
            showata()
            clear()
            con.Close()
        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim show As Integer
        show = DataGridView1.CurrentRow.Index
        txtroomsid.Text = DataGridView1.Item(0, show).Value
        txtroomsno.Text = DataGridView1.Item(1, show).Value
        CCbroomstype.Text = DataGridView1.Item(2, show).Value

    End Sub

    Private Sub BTNrefrrsh_Click(sender As Object, e As EventArgs) Handles BTNrefrrsh.Click
        clear()
    End Sub

    Private Sub Btndelete_Click_1(sender As Object, e As EventArgs) Handles Btndelete.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        If txtroomsid.Text = "" Or txtroomsno.Text = "" Or CCbroomstype.Text = "" Then
            MessageBox.Show("Please select your info to delete", "notice", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If MessageBox.Show("Are you sure want to delete the info", "notice", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "DELETE FROM Rooms WHERE roomid=@id"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtroomsid.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If
    End Sub
End Class
