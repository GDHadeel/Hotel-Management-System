﻿Public Class Mainform
    Private Sub Btninsert_Click(sender As Object, e As EventArgs) Handles Btnexit1.Click
        Dim login As New LoginForm
        login.Show()
        Me.Hide()
    End Sub

    Private Sub Btnclient_Click(sender As Object, e As EventArgs) Handles Btnclient.Click
        UClients1.BringToFront()
        lblcusor.Left = Btnclient.Left
    End Sub

    Private Sub Btnroom_Click(sender As Object, e As EventArgs) Handles Btnroom.Click
        URooms1.BringToFront()
        lblcusor.Left = Btnroom.Left
    End Sub

    Private Sub BtnReservation_Click(sender As Object, e As EventArgs) Handles BtnReservation.Click
        UReservation1.BringToFront()
        lblcusor.Left = BtnReservation.Left
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)
        UClients1.BringToFront()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        WindowState = FormWindowState.Minimized
    End Sub
End Class