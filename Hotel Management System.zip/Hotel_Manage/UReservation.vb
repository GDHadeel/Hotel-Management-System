﻿Imports System.Data.SqlClient
Imports System.Data
Public Class UReservation

    Private Sub UReservation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        showata()
        CCBresgender.Text = "none"
        CCBresgender.Items.Add("Male")
        CCBresgender.Items.Add("Female")
    End Sub

    Sub showata()
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM Reservations"
        Dim da As New SqlDataAdapter(cmd.CommandText, con)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        con.Close()
    End Sub

    Sub clear()
        txtresid.Text = ""
        txtresname.Text = ""
        txtreslname.Text = ""
        txtresemail.Text = ""
        CCBresgender.Text = ""
        dtresdate.Text = ""
    End Sub

    Private Sub Btninsert_Click(sender As Object, e As EventArgs) Handles Btninsert.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        con = getconnection()
        con.Open()
        cmd = con.CreateCommand
        cmd.CommandText = "SELECT * FROM Reservations WHERE resid=@id"
        cmd.Parameters.AddWithValue("id", txtresid.Text)
        Dim dr As SqlDataReader = cmd.ExecuteReader
        If dr.HasRows Then
            MessageBox.Show("The" & txtresid.Text & "resid Is already existed")
            clear()
        Else
            If txtresid.Text = "" Or txtresname.Text = "" Or txtreslname.Text = "" Or CCBresgender.Text = "" Or txtresemail.Text = "" Or dtresdate.Text = "" Then
                MessageBox.Show("Please insert your info")
            Else
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "INSERT INTO Reservations(resid, resname, reslname, resgender, resemail, resdate)  VALUES(@id, @name, @lname, @gender, @email, @date)"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtresid.Text)
                cmd.Parameters.AddWithValue("name", txtresname.Text)
                cmd.Parameters.AddWithValue("lname", txtreslname.Text)
                cmd.Parameters.AddWithValue("gender", CCBresgender.Text)
                cmd.Parameters.AddWithValue("email", txtresemail.Text)
                cmd.Parameters.AddWithValue("date", dtresdate.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If
    End Sub



    Private Sub Btnupdate_Click(sender As Object, e As EventArgs) Handles Btnupdate.Click
        If txtresid.Text = "" Or txtresname.Text = "" Or txtreslname.Text = "" Or CCBresgender.Text = "" Or txtresemail.Text = "" Or dtresdate.Text = "" Then
            MessageBox.Show("Please selsct your info")
        Else
            Dim con As New SqlConnection
            Dim cmd As New SqlCommand
            con = getconnection()
            con.Open()
            cmd = con.CreateCommand
            cmd.CommandText = "UPDATE Reservations SET resname=@name, resname=@name, resgender=@gender, resemail=@email, resdate=@date WHERE resid=@id"
            Dim da As New SqlDataAdapter(cmd.CommandText, con)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("id", txtresid.Text)
            cmd.Parameters.AddWithValue("name", txtresname.Text)
            cmd.Parameters.AddWithValue("lname", txtreslname.Text)
            cmd.Parameters.AddWithValue("gender", CCBresgender.Text)
            cmd.Parameters.AddWithValue("email", txtresemail.Text)
            cmd.Parameters.AddWithValue("date", dtresdate.Text)
            cmd.ExecuteNonQuery()
            showata()
            clear()
            con.Close()

        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim show As Integer
        show = DataGridView1.CurrentRow.Index
        txtresid.Text = DataGridView1.Item(0, show).Value
        txtresname.Text = DataGridView1.Item(1, show).Value
        txtreslname.Text = DataGridView1.Item(2, show).Value
        CCBresgender.Text = DataGridView1.Item(3, show).Value
        txtresemail.Text = DataGridView1.Item(4, show).Value
        dtresdate.Text = DataGridView1.Item(5, show).Value
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        If txtresid.Text = "" Or txtresname.Text = "" Or txtreslname.Text = "" Or CCBresgender.Text = "" Or txtresemail.Text = "" Or dtresdate.Text = "" Then
            MessageBox.Show("Please select your info you want to delete", "notice", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If MessageBox.Show("Are you sure want to delete this info", "notice", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                con = getconnection()
                con.Open()
                cmd = con.CreateCommand
                cmd.CommandText = "DELETE FROM Reservations WHERE resid=@id"
                Dim da As New SqlDataAdapter(cmd.CommandText, con)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("id", txtresid.Text)
                cmd.ExecuteNonQuery()
                showata()
                clear()
                con.Close()
            End If
        End If
    End Sub
End Class
