﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class URooms
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.CCbroomstype = New System.Windows.Forms.ComboBox()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Btnupdate = New System.Windows.Forms.Button()
        Me.Btninsert = New System.Windows.Forms.Button()
        Me.txtroomsno = New System.Windows.Forms.TextBox()
        Me.txtroomsid = New System.Windows.Forms.TextBox()
        Me.lblroomstype = New System.Windows.Forms.Label()
        Me.Lblroomsno = New System.Windows.Forms.Label()
        Me.lblroomsid = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BTNrefrrsh = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.btnexit)
        Me.Panel1.Location = New System.Drawing.Point(589, 149)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(557, 462)
        Me.Panel1.TabIndex = 81
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 33
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(551, 456)
        Me.DataGridView1.TabIndex = 93
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Red
        Me.btnexit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnexit.ForeColor = System.Drawing.Color.White
        Me.btnexit.Location = New System.Drawing.Point(1037, 21)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(52, 47)
        Me.btnexit.TabIndex = 1
        Me.btnexit.Text = "X"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'CCbroomstype
        '
        Me.CCbroomstype.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CCbroomstype.FormattingEnabled = True
        Me.CCbroomstype.Location = New System.Drawing.Point(188, 408)
        Me.CCbroomstype.Name = "CCbroomstype"
        Me.CCbroomstype.Size = New System.Drawing.Size(356, 40)
        Me.CCbroomstype.TabIndex = 80
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.Color.Red
        Me.Btndelete.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btndelete.ForeColor = System.Drawing.Color.White
        Me.Btndelete.Location = New System.Drawing.Point(387, 555)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(157, 56)
        Me.Btndelete.TabIndex = 77
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'Btnupdate
        '
        Me.Btnupdate.BackColor = System.Drawing.Color.Orange
        Me.Btnupdate.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnupdate.ForeColor = System.Drawing.Color.White
        Me.Btnupdate.Location = New System.Drawing.Point(206, 555)
        Me.Btnupdate.Name = "Btnupdate"
        Me.Btnupdate.Size = New System.Drawing.Size(157, 56)
        Me.Btnupdate.TabIndex = 76
        Me.Btnupdate.Text = "UPDATE"
        Me.Btnupdate.UseVisualStyleBackColor = False
        '
        'Btninsert
        '
        Me.Btninsert.BackColor = System.Drawing.Color.Green
        Me.Btninsert.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btninsert.ForeColor = System.Drawing.Color.White
        Me.Btninsert.Location = New System.Drawing.Point(25, 555)
        Me.Btninsert.Name = "Btninsert"
        Me.Btninsert.Size = New System.Drawing.Size(157, 56)
        Me.Btninsert.TabIndex = 75
        Me.Btninsert.Text = "INSERT"
        Me.Btninsert.UseVisualStyleBackColor = False
        '
        'txtroomsno
        '
        Me.txtroomsno.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtroomsno.Location = New System.Drawing.Point(188, 310)
        Me.txtroomsno.Name = "txtroomsno"
        Me.txtroomsno.Size = New System.Drawing.Size(356, 39)
        Me.txtroomsno.TabIndex = 74
        '
        'txtroomsid
        '
        Me.txtroomsid.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtroomsid.Location = New System.Drawing.Point(188, 203)
        Me.txtroomsid.Name = "txtroomsid"
        Me.txtroomsid.Size = New System.Drawing.Size(356, 39)
        Me.txtroomsid.TabIndex = 73
        '
        'lblroomstype
        '
        Me.lblroomstype.AutoSize = True
        Me.lblroomstype.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblroomstype.Location = New System.Drawing.Point(20, 414)
        Me.lblroomstype.Name = "lblroomstype"
        Me.lblroomstype.Size = New System.Drawing.Size(162, 28)
        Me.lblroomstype.TabIndex = 72
        Me.lblroomstype.Text = "Rooms Type:"
        '
        'Lblroomsno
        '
        Me.Lblroomsno.AutoSize = True
        Me.Lblroomsno.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Lblroomsno.Location = New System.Drawing.Point(45, 316)
        Me.Lblroomsno.Name = "Lblroomsno"
        Me.Lblroomsno.Size = New System.Drawing.Size(137, 28)
        Me.Lblroomsno.TabIndex = 71
        Me.Lblroomsno.Text = "Rooms No:"
        '
        'lblroomsid
        '
        Me.lblroomsid.AutoSize = True
        Me.lblroomsid.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblroomsid.Location = New System.Drawing.Point(54, 209)
        Me.lblroomsid.Name = "lblroomsid"
        Me.lblroomsid.Size = New System.Drawing.Size(128, 28)
        Me.lblroomsid.TabIndex = 70
        Me.lblroomsid.Text = "Rooms Id:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Britannic Bold", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(206, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 58)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "ROOMS"
        '
        'BTNrefrrsh
        '
        Me.BTNrefrrsh.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BTNrefrrsh.FlatAppearance.BorderSize = 0
        Me.BTNrefrrsh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNrefrrsh.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BTNrefrrsh.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.BTNrefrrsh.Location = New System.Drawing.Point(25, 482)
        Me.BTNrefrrsh.Name = "BTNrefrrsh"
        Me.BTNrefrrsh.Size = New System.Drawing.Size(519, 49)
        Me.BTNrefrrsh.TabIndex = 94
        Me.BTNrefrrsh.Text = "REFRRSH"
        Me.BTNrefrrsh.UseVisualStyleBackColor = False
        '
        'URooms
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.BTNrefrrsh)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CCbroomstype)
        Me.Controls.Add(Me.Btndelete)
        Me.Controls.Add(Me.Btnupdate)
        Me.Controls.Add(Me.Btninsert)
        Me.Controls.Add(Me.txtroomsno)
        Me.Controls.Add(Me.txtroomsid)
        Me.Controls.Add(Me.lblroomstype)
        Me.Controls.Add(Me.Lblroomsno)
        Me.Controls.Add(Me.lblroomsid)
        Me.Controls.Add(Me.Label1)
        Me.Name = "URooms"
        Me.Size = New System.Drawing.Size(1166, 670)
        Me.Panel1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnexit As Button
    Friend WithEvents CCbroomstype As ComboBox
    Friend WithEvents Btndelete As Button
    Friend WithEvents Btnupdate As Button
    Friend WithEvents Btninsert As Button
    Friend WithEvents txtroomsno As TextBox
    Friend WithEvents txtroomsid As TextBox
    Friend WithEvents lblroomstype As Label
    Friend WithEvents Lblroomsno As Label
    Friend WithEvents lblroomsid As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BTNrefrrsh As Button
End Class
